"""
Failure Prediction Module
Uses sliding window analysis and trend detection to predict failures before they occur.
"""

import logging
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
from collections import deque

import numpy as np
from scipy import stats
from scipy.signal import savgol_filter

from src.config import get_config
from src.collector.metrics_collector import ClusterMetrics

logger = logging.getLogger(__name__)


class FailureType(Enum):
    """Types of predicted failures."""
    CPU_EXHAUSTION = "cpu_exhaustion"
    MEMORY_EXHAUSTION = "memory_exhaustion"
    ERROR_SPIKE = "error_spike"
    LATENCY_DEGRADATION = "latency_degradation"
    CASCADE_FAILURE = "cascade_failure"
    UNKNOWN = "unknown"


class TrendDirection(Enum):
    """Trend direction for metrics."""
    INCREASING = "increasing"
    DECREASING = "decreasing"
    STABLE = "stable"
    VOLATILE = "volatile"


@dataclass
class TrendAnalysis:
    """Result of trend analysis for a single metric."""
    metric_name: str
    direction: TrendDirection
    slope: float  # Rate of change per minute
    r_squared: float  # Confidence in trend
    current_value: float
    predicted_value_15m: float
    will_breach_threshold: bool
    time_to_breach_minutes: Optional[float] = None


@dataclass
class FailurePrediction:
    """Prediction of potential failure."""
    timestamp: datetime
    failure_type: FailureType
    probability: float  # 0-1
    confidence: float  # 0-1
    estimated_time_to_failure: Optional[timedelta]
    affected_components: List[str]
    trend_analysis: Dict[str, TrendAnalysis]
    recommended_action: str
    supporting_evidence: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "failure_type": self.failure_type.value,
            "probability": round(self.probability, 4),
            "confidence": round(self.confidence, 4),
            "estimated_time_to_failure_minutes": (
                self.estimated_time_to_failure.total_seconds() / 60
                if self.estimated_time_to_failure else None
            ),
            "affected_components": self.affected_components,
            "recommended_action": self.recommended_action,
            "supporting_evidence": self.supporting_evidence,
            "trend_analysis": {
                k: {
                    "direction": v.direction.value,
                    "slope": round(v.slope, 4),
                    "current": round(v.current_value, 2),
                    "predicted_15m": round(v.predicted_value_15m, 2),
                    "will_breach": v.will_breach_threshold
                }
                for k, v in self.trend_analysis.items()
            }
        }
    
    @property
    def is_actionable(self) -> bool:
        """Whether this prediction warrants action."""
        return self.probability >= 0.7 and self.confidence >= 0.6


class MetricsBuffer:
    """
    Circular buffer for storing historical metrics.
    Enables efficient sliding window analysis.
    """
    
    def __init__(self, max_size: int = 120):  # 2 hours at 1-minute intervals
        self.max_size = max_size
        self.buffer: deque = deque(maxlen=max_size)
    
    def add(self, metrics: ClusterMetrics) -> None:
        """Add metrics to buffer."""
        self.buffer.append(metrics)
    
    def get_window(self, minutes: int) -> List[ClusterMetrics]:
        """Get last N minutes of metrics."""
        return list(self.buffer)[-minutes:]
    
    def get_metric_series(self, metric_name: str, minutes: int = None) -> np.ndarray:
        """Extract a single metric as numpy array."""
        window = self.get_window(minutes) if minutes else list(self.buffer)
        return np.array([getattr(m, metric_name) for m in window])
    
    def __len__(self) -> int:
        return len(self.buffer)
    
    @property
    def is_ready(self) -> bool:
        """Whether buffer has enough data for prediction."""
        return len(self.buffer) >= 15  # At least 15 minutes


class TrendAnalyzer:
    """
    Analyzes metric trends using statistical methods.
    """
    
    # Thresholds for different metrics
    THRESHOLDS = {
        "cpu_usage_percent": 90,
        "memory_usage_percent": 95,
        "error_rate_per_second": 10,
        "latency_p99_ms": 2000,
        "request_rate_per_second": None  # No upper threshold
    }
    
    def analyze(
        self, 
        values: np.ndarray, 
        metric_name: str,
        prediction_minutes: int = 15
    ) -> TrendAnalysis:
        """
        Analyze trend for a single metric.
        
        Args:
            values: Array of metric values (1 per minute)
            metric_name: Name of the metric
            prediction_minutes: How far ahead to predict
            
        Returns:
            TrendAnalysis with direction, slope, and predictions
        """
        if len(values) < 5:
            return self._default_analysis(metric_name, values[-1] if len(values) > 0 else 0)
        
        # Smooth the data to reduce noise
        if len(values) >= 7:
            smoothed = savgol_filter(values, window_length=7, polyorder=2)
        else:
            smoothed = values
        
        # Linear regression for trend
        x = np.arange(len(smoothed))
        slope, intercept, r_value, p_value, std_err = stats.linregress(x, smoothed)
        r_squared = r_value ** 2
        
        # Determine trend direction
        if abs(slope) < 0.01 * np.mean(values):  # Less than 1% change
            direction = TrendDirection.STABLE
        elif slope > 0:
            direction = TrendDirection.INCREASING
        else:
            direction = TrendDirection.DECREASING
        
        # Check for volatility
        cv = np.std(values) / (np.mean(values) + 1e-10)  # Coefficient of variation
        if cv > 0.5:
            direction = TrendDirection.VOLATILE
        
        # Predict future value
        current_value = values[-1]
        predicted_value = intercept + slope * (len(values) + prediction_minutes)
        
        # Check if threshold will be breached
        threshold = self.THRESHOLDS.get(metric_name)
        will_breach = False
        time_to_breach = None
        
        if threshold and direction == TrendDirection.INCREASING:
            if predicted_value >= threshold:
                will_breach = True
                # Calculate time to breach
                if slope > 0:
                    time_to_breach = (threshold - current_value) / slope
                    if time_to_breach < 0:
                        time_to_breach = 0
        
        return TrendAnalysis(
            metric_name=metric_name,
            direction=direction,
            slope=slope,
            r_squared=r_squared,
            current_value=current_value,
            predicted_value_15m=predicted_value,
            will_breach_threshold=will_breach,
            time_to_breach_minutes=time_to_breach
        )
    
    def _default_analysis(self, metric_name: str, current_value: float) -> TrendAnalysis:
        """Default analysis when insufficient data."""
        return TrendAnalysis(
            metric_name=metric_name,
            direction=TrendDirection.STABLE,
            slope=0,
            r_squared=0,
            current_value=current_value,
            predicted_value_15m=current_value,
            will_breach_threshold=False
        )


class FailurePredictor:
    """
    Predicts infrastructure failures using sliding window analysis.
    
    Features:
    - Multi-metric trend analysis
    - Failure probability scoring
    - Time-to-failure estimation
    - Actionable recommendations
    """
    
    def __init__(self):
        self.config = get_config()
        self.buffer = MetricsBuffer()
        self.trend_analyzer = TrendAnalyzer()
        self.prediction_window = self.config.prediction.window_minutes
        
        logger.info(f"FailurePredictor initialized with {self.prediction_window}min window")
    
    def add_metrics(self, metrics: ClusterMetrics) -> None:
        """Add new metrics to the buffer."""
        self.buffer.add(metrics)
    
    def predict(self) -> Optional[FailurePrediction]:
        """
        Analyze current trends and predict potential failures.
        
        Returns:
            FailurePrediction if risk detected, None otherwise
        """
        if not self.buffer.is_ready:
            logger.debug(f"Buffer not ready: {len(self.buffer)} samples")
            return None
        
        # Analyze trends for each metric
        metrics_to_analyze = [
            "cpu_usage_percent",
            "memory_usage_percent", 
            "error_rate_per_second",
            "latency_p99_ms"
        ]
        
        trend_analysis = {}
        for metric_name in metrics_to_analyze:
            values = self.buffer.get_metric_series(metric_name, self.prediction_window)
            trend_analysis[metric_name] = self.trend_analyzer.analyze(
                values, metric_name, self.prediction_window
            )
        
        # Determine failure type and probability
        failure_type, probability, evidence = self._classify_failure(trend_analysis)
        
        if probability < 0.3:
            return None  # No significant risk
        
        # Calculate confidence based on trend consistency
        confidence = self._calculate_confidence(trend_analysis)
        
        # Estimate time to failure
        time_to_failure = self._estimate_time_to_failure(trend_analysis)
        
        # Get affected components
        affected = [
            ta.metric_name for ta in trend_analysis.values()
            if ta.will_breach_threshold or ta.direction == TrendDirection.INCREASING
        ]
        
        # Generate recommendation
        recommendation = self._generate_recommendation(failure_type, trend_analysis)
        
        prediction = FailurePrediction(
            timestamp=datetime.utcnow(),
            failure_type=failure_type,
            probability=probability,
            confidence=confidence,
            estimated_time_to_failure=time_to_failure,
            affected_components=affected,
            trend_analysis=trend_analysis,
            recommended_action=recommendation,
            supporting_evidence=evidence
        )
        
        logger.info(
            f"Failure prediction: type={failure_type.value}, "
            f"prob={probability:.2f}, conf={confidence:.2f}, "
            f"ttf={time_to_failure}"
        )
        
        return prediction
    
    def _classify_failure(
        self, 
        trends: Dict[str, TrendAnalysis]
    ) -> Tuple[FailureType, float, List[str]]:
        """
        Classify the type of failure and calculate probability.
        """
        evidence = []
        scores = {
            FailureType.CPU_EXHAUSTION: 0,
            FailureType.MEMORY_EXHAUSTION: 0,
            FailureType.ERROR_SPIKE: 0,
            FailureType.LATENCY_DEGRADATION: 0,
            FailureType.CASCADE_FAILURE: 0
        }
        
        cpu = trends.get("cpu_usage_percent")
        memory = trends.get("memory_usage_percent")
        errors = trends.get("error_rate_per_second")
        latency = trends.get("latency_p99_ms")
        
        # CPU exhaustion signals
        if cpu and cpu.will_breach_threshold:
            scores[FailureType.CPU_EXHAUSTION] += 0.6
            evidence.append(f"CPU trending toward {cpu.predicted_value_15m:.1f}%")
        if cpu and cpu.current_value > 80:
            scores[FailureType.CPU_EXHAUSTION] += 0.3
            evidence.append(f"CPU already at {cpu.current_value:.1f}%")
        
        # Memory exhaustion signals
        if memory and memory.will_breach_threshold:
            scores[FailureType.MEMORY_EXHAUSTION] += 0.7
            evidence.append(f"Memory trending toward {memory.predicted_value_15m:.1f}%")
        if memory and memory.current_value > 85:
            scores[FailureType.MEMORY_EXHAUSTION] += 0.3
            evidence.append(f"Memory already at {memory.current_value:.1f}%")
        
        # Error spike signals
        if errors and errors.direction == TrendDirection.INCREASING:
            scores[FailureType.ERROR_SPIKE] += 0.5
            evidence.append(f"Error rate increasing: slope={errors.slope:.3f}/min")
        if errors and errors.current_value > 5:
            scores[FailureType.ERROR_SPIKE] += 0.4
            evidence.append(f"Error rate elevated: {errors.current_value:.2f}/s")
        
        # Latency degradation signals
        if latency and latency.will_breach_threshold:
            scores[FailureType.LATENCY_DEGRADATION] += 0.5
            evidence.append(f"Latency trending toward {latency.predicted_value_15m:.0f}ms")
        if latency and latency.current_value > 1000:
            scores[FailureType.LATENCY_DEGRADATION] += 0.4
            evidence.append(f"Latency already at {latency.current_value:.0f}ms")
        
        # Cascade failure - multiple systems degrading
        degrading_count = sum(
            1 for t in trends.values()
            if t.direction == TrendDirection.INCREASING and t.will_breach_threshold
        )
        if degrading_count >= 2:
            scores[FailureType.CASCADE_FAILURE] += 0.8
            evidence.append(f"{degrading_count} metrics trending toward breach")
        
        # Find highest scoring failure type
        max_type = max(scores, key=scores.get)
        probability = min(scores[max_type], 1.0)
        
        if probability < 0.3:
            return FailureType.UNKNOWN, probability, evidence
        
        return max_type, probability, evidence
    
    def _calculate_confidence(self, trends: Dict[str, TrendAnalysis]) -> float:
        """Calculate confidence based on trend consistency."""
        r_squared_values = [t.r_squared for t in trends.values()]
        
        if not r_squared_values:
            return 0.5
        
        # Higher R² = more consistent trends = higher confidence
        avg_r_squared = np.mean(r_squared_values)
        
        # Adjust for buffer size
        buffer_factor = min(len(self.buffer) / 60, 1.0)  # Full confidence at 60 samples
        
        return avg_r_squared * 0.7 + buffer_factor * 0.3
    
    def _estimate_time_to_failure(
        self, 
        trends: Dict[str, TrendAnalysis]
    ) -> Optional[timedelta]:
        """Estimate time until failure occurs."""
        times_to_breach = [
            t.time_to_breach_minutes 
            for t in trends.values() 
            if t.time_to_breach_minutes is not None and t.time_to_breach_minutes > 0
        ]
        
        if not times_to_breach:
            return None
        
        # Use minimum time to any breach
        min_time = min(times_to_breach)
        return timedelta(minutes=min_time)
    
    def _generate_recommendation(
        self, 
        failure_type: FailureType,
        trends: Dict[str, TrendAnalysis]
    ) -> str:
        """Generate actionable recommendation."""
        recommendations = {
            FailureType.CPU_EXHAUSTION: "Scale out pods via HPA or reduce CPU-intensive operations",
            FailureType.MEMORY_EXHAUSTION: "Initiate rolling restart to clear memory, check for leaks",
            FailureType.ERROR_SPIKE: "Check recent deployments, review error logs, consider rollback",
            FailureType.LATENCY_DEGRADATION: "Check database connections, downstream services, and network",
            FailureType.CASCADE_FAILURE: "Multiple systems degrading - consider emergency scaling or rollback",
            FailureType.UNKNOWN: "Monitor closely, investigate anomalous metrics"
        }
        
        base_rec = recommendations.get(failure_type, "Investigate system health")
        
        # Add specific details
        cpu = trends.get("cpu_usage_percent")
        if cpu and cpu.time_to_breach_minutes and cpu.time_to_breach_minutes < 10:
            base_rec += f" (CPU breach in ~{cpu.time_to_breach_minutes:.0f} min)"
        
        return base_rec


# Singleton instance
_predictor: Optional[FailurePredictor] = None


def get_predictor() -> FailurePredictor:
    """Get the global FailurePredictor instance."""
    global _predictor
    if _predictor is None:
        _predictor = FailurePredictor()
    return _predictor
