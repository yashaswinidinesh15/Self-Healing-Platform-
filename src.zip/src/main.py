"""
SelfHealStack - Main Orchestration Module
Coordinates metrics collection, anomaly detection, prediction, and remediation.
"""

import asyncio
import logging
import signal
import sys
from datetime import datetime, timedelta
from typing import Optional

from src.config import get_config
from src.collector.metrics_collector import get_collector, ClusterMetrics
from src.detector.anomaly_detector import get_detector, AnomalyResult, AnomalySeverity
from src.predictor.failure_predictor import get_predictor, FailurePrediction
from src.remediator.auto_remediator import get_remediator, ActionResult
from src.notifier.slack_notifier import get_notifier

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)-20s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

logger = logging.getLogger("selfhealstack")


class SelfHealStack:
    """
    Main orchestration engine for autonomous infrastructure healing.
    
    Workflow:
    1. Collect metrics from Prometheus (every 60s)
    2. Detect anomalies using Isolation Forest
    3. Predict failures using sliding window analysis
    4. Plan and execute remediation actions
    5. Send notifications via Slack
    """
    
    def __init__(self):
        self.config = get_config()
        
        # Initialize components
        self.collector = get_collector()
        self.detector = get_detector()
        self.predictor = get_predictor()
        self.remediator = get_remediator()
        self.notifier = get_notifier()
        
        # State tracking
        self.running = False
        self.iteration_count = 0
        self.anomalies_detected = 0
        self.predictions_made = 0
        self.actions_taken = 0
        self.start_time: Optional[datetime] = None
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self._handle_shutdown)
        signal.signal(signal.SIGTERM, self._handle_shutdown)
        
        logger.info("SelfHealStack initialized")
    
    def _handle_shutdown(self, signum, frame):
        """Handle graceful shutdown."""
        logger.info(f"Received signal {signum}, shutting down...")
        self.running = False
    
    async def _train_model_if_needed(self) -> None:
        """Train anomaly detection model if not already trained."""
        if self.detector.is_trained:
            logger.info("Anomaly detection model already trained")
            return
        
        logger.info("Training anomaly detection model on historical data...")
        
        try:
            # Fetch historical data
            historical_df = self.collector.fetch_historical_metrics(
                duration_minutes=120,  # 2 hours
                step_seconds=60
            )
            
            if len(historical_df) >= 30:
                self.detector.train(historical_df)
                logger.info(f"Model trained on {len(historical_df)} samples")
            else:
                logger.warning(
                    f"Insufficient data for training ({len(historical_df)} samples). "
                    "Will use threshold-based detection."
                )
                
        except Exception as e:
            logger.error(f"Failed to train model: {e}")
    
    async def _process_iteration(self) -> None:
        """Execute one iteration of the healing loop."""
        self.iteration_count += 1
        logger.info(f"=== Iteration {self.iteration_count} ===")
        
        try:
            # Step 1: Collect current metrics
            metrics = self.collector.fetch_current_metrics()
            
            # Step 2: Add to predictor buffer
            self.predictor.add_metrics(metrics)
            
            # Step 3: Detect anomalies
            anomaly_result = self.detector.detect(metrics)
            
            if anomaly_result.is_anomaly:
                self.anomalies_detected += 1
                logger.warning(
                    f"Anomaly detected: score={anomaly_result.anomaly_score:.3f}, "
                    f"severity={anomaly_result.severity.value}"
                )
                
                # Send alert for critical anomalies
                if anomaly_result.severity == AnomalySeverity.CRITICAL:
                    self.notifier.send_anomaly_alert(anomaly_result)
            
            # Step 4: Predict failures
            prediction = self.predictor.predict()
            
            if prediction and prediction.is_actionable:
                self.predictions_made += 1
                logger.warning(
                    f"Failure predicted: type={prediction.failure_type.value}, "
                    f"probability={prediction.probability:.0%}"
                )
                
                # Send prediction alert
                self.notifier.send_prediction_alert(prediction)
            
            # Step 5: Plan remediation
            action = self.remediator.plan_action(
                anomaly=anomaly_result if anomaly_result.is_anomaly else None,
                prediction=prediction
            )
            
            # Step 6: Execute remediation
            if action:
                logger.info(f"Executing remediation: {action.action_type.value}")
                result = await self.remediator.execute(action)
                
                self.actions_taken += 1
                
                # Send remediation notification
                self.notifier.send_remediation_result(result)
                
                logger.info(f"Remediation result: {result.status.value}")
            
            logger.info(f"Iteration {self.iteration_count} completed")
            
        except Exception as e:
            logger.error(f"Error in iteration {self.iteration_count}: {e}", exc_info=True)
    
    async def run(self) -> None:
        """
        Main run loop.
        Executes healing iterations at configured intervals.
        """
        self.running = True
        self.start_time = datetime.utcnow()
        
        logger.info("=" * 60)
        logger.info("  SelfHealStack - Autonomous Infrastructure Recovery")
        logger.info("=" * 60)
        logger.info(f"  Prometheus: {self.config.prometheus.url}")
        logger.info(f"  Namespace: {self.config.kubernetes.namespace}")
        logger.info(f"  Dry Run: {self.config.remediation.dry_run}")
        logger.info(f"  Interval: {self.config.prometheus.scrape_interval_seconds}s")
        logger.info("=" * 60)
        
        # Health check
        if not self.collector.health_check():
            logger.error("Prometheus health check failed!")
            return
        
        logger.info("Prometheus connection verified ✓")
        
        # Train model on startup
        await self._train_model_if_needed()
        
        # Main loop
        logger.info("Starting healing loop...")
        
        while self.running:
            try:
                await self._process_iteration()
                
                # Wait for next interval
                await asyncio.sleep(self.config.prometheus.scrape_interval_seconds)
                
            except asyncio.CancelledError:
                logger.info("Healing loop cancelled")
                break
            except Exception as e:
                logger.error(f"Unexpected error: {e}", exc_info=True)
                await asyncio.sleep(10)  # Brief pause before retry
        
        # Shutdown summary
        runtime = datetime.utcnow() - self.start_time
        logger.info("=" * 60)
        logger.info("  SelfHealStack Shutdown Summary")
        logger.info("=" * 60)
        logger.info(f"  Runtime: {runtime}")
        logger.info(f"  Iterations: {self.iteration_count}")
        logger.info(f"  Anomalies Detected: {self.anomalies_detected}")
        logger.info(f"  Predictions Made: {self.predictions_made}")
        logger.info(f"  Actions Taken: {self.actions_taken}")
        logger.info("=" * 60)
    
    def get_status(self) -> dict:
        """Get current status for API."""
        return {
            "running": self.running,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "uptime_seconds": (
                (datetime.utcnow() - self.start_time).total_seconds()
                if self.start_time else 0
            ),
            "iteration_count": self.iteration_count,
            "anomalies_detected": self.anomalies_detected,
            "predictions_made": self.predictions_made,
            "actions_taken": self.actions_taken,
            "config": {
                "prometheus_url": self.config.prometheus.url,
                "namespace": self.config.kubernetes.namespace,
                "dry_run": self.config.remediation.dry_run,
                "remediation_enabled": self.config.remediation.enabled
            }
        }


async def main():
    """Main entry point."""
    stack = SelfHealStack()
    await stack.run()


if __name__ == "__main__":
    asyncio.run(main())
