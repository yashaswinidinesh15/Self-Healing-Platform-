"""
SelfHealStack Configuration Management
Centralized configuration with environment variable support and validation.
"""

import os
from dataclasses import dataclass, field
from typing import List, Optional
from pathlib import Path
import yaml
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


@dataclass
class PrometheusConfig:
    """Prometheus connection configuration."""
    url: str = field(default_factory=lambda: os.getenv("PROMETHEUS_URL", "http://localhost:9090"))
    timeout_seconds: int = 30
    retry_attempts: int = 3
    scrape_interval_seconds: int = 60


@dataclass
class KubernetesConfig:
    """Kubernetes cluster configuration."""
    kubeconfig_path: Optional[str] = field(default_factory=lambda: os.getenv("KUBECONFIG"))
    namespace: str = field(default_factory=lambda: os.getenv("NAMESPACE", "default"))
    in_cluster: bool = field(default_factory=lambda: os.getenv("IN_CLUSTER", "false").lower() == "true")
    excluded_namespaces: List[str] = field(default_factory=lambda: ["kube-system", "monitoring", "istio-system"])


@dataclass
class SlackConfig:
    """Slack notification configuration."""
    webhook_url: str = field(default_factory=lambda: os.getenv("SLACK_WEBHOOK_URL", ""))
    channel: str = field(default_factory=lambda: os.getenv("SLACK_CHANNEL", "#incidents"))
    username: str = "SelfHealStack"
    icon_emoji: str = ":robot_face:"
    enabled: bool = field(default_factory=lambda: bool(os.getenv("SLACK_WEBHOOK_URL")))


@dataclass
class KafkaConfig:
    """Kafka streaming configuration."""
    bootstrap_servers: str = field(default_factory=lambda: os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"))
    topic: str = field(default_factory=lambda: os.getenv("KAFKA_TOPIC", "healing-events"))
    consumer_group: str = "selfhealstack-consumers"
    enabled: bool = field(default_factory=lambda: os.getenv("KAFKA_ENABLED", "true").lower() == "true")


@dataclass
class DatabaseConfig:
    """PostgreSQL database configuration."""
    url: str = field(default_factory=lambda: os.getenv("DATABASE_URL", "postgresql://localhost:5432/selfhealstack"))
    pool_size: int = 5
    max_overflow: int = 10


@dataclass
class AnomalyDetectionConfig:
    """Anomaly detection model configuration."""
    algorithm: str = "isolation_forest"
    contamination: float = 0.1
    n_estimators: int = 100
    threshold_warning: float = 0.6
    threshold_critical: float = 0.8
    model_path: str = "models/isolation_forest.pkl"
    features: List[str] = field(default_factory=lambda: [
        "cpu_usage_percent",
        "memory_usage_percent", 
        "error_rate_per_second",
        "latency_p99_ms",
        "request_rate_per_second"
    ])


@dataclass
class PredictionConfig:
    """Failure prediction configuration."""
    window_minutes: int = field(default_factory=lambda: int(os.getenv("PREDICTION_WINDOW_MINUTES", "15")))
    datapoints_required: int = 60
    confidence_threshold: float = 0.7
    trend_sensitivity: float = 0.1


@dataclass
class RemediationConfig:
    """Auto-remediation configuration."""
    enabled: bool = field(default_factory=lambda: os.getenv("REMEDIATION_ENABLED", "true").lower() == "true")
    dry_run: bool = field(default_factory=lambda: os.getenv("DRY_RUN", "false").lower() == "true")
    cooldown_seconds: int = field(default_factory=lambda: int(os.getenv("COOLDOWN_SECONDS", "300")))
    max_actions_per_hour: int = 10
    
    # Per-action limits
    pod_restart_max_per_hour: int = 3
    hpa_scale_max_replicas: int = 10
    hpa_scale_up_percent: int = 50
    rollback_require_approval: bool = True
    rollback_max_revisions: int = 3


@dataclass
class Config:
    """Main configuration container."""
    prometheus: PrometheusConfig = field(default_factory=PrometheusConfig)
    kubernetes: KubernetesConfig = field(default_factory=KubernetesConfig)
    slack: SlackConfig = field(default_factory=SlackConfig)
    kafka: KafkaConfig = field(default_factory=KafkaConfig)
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    anomaly: AnomalyDetectionConfig = field(default_factory=AnomalyDetectionConfig)
    prediction: PredictionConfig = field(default_factory=PredictionConfig)
    remediation: RemediationConfig = field(default_factory=RemediationConfig)
    
    # Application settings
    log_level: str = field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO"))
    metrics_port: int = field(default_factory=lambda: int(os.getenv("METRICS_PORT", "8000")))
    health_check_interval: int = 60

    @classmethod
    def from_yaml(cls, path: str) -> "Config":
        """Load configuration from YAML file."""
        config_path = Path(path)
        if not config_path.exists():
            return cls()
        
        with open(config_path) as f:
            yaml_config = yaml.safe_load(f)
        
        # Merge YAML with defaults
        config = cls()
        if yaml_config:
            # Update nested configs from YAML
            pass  # Implement as needed
        
        return config
    
    def validate(self) -> List[str]:
        """Validate configuration and return list of errors."""
        errors = []
        
        if not self.prometheus.url:
            errors.append("PROMETHEUS_URL is required")
        
        if self.slack.enabled and not self.slack.webhook_url:
            errors.append("SLACK_WEBHOOK_URL is required when Slack is enabled")
        
        if self.anomaly.contamination <= 0 or self.anomaly.contamination >= 0.5:
            errors.append("Anomaly contamination must be between 0 and 0.5")
        
        if self.remediation.cooldown_seconds < 60:
            errors.append("Cooldown must be at least 60 seconds")
        
        return errors


# Global config instance
_config: Optional[Config] = None


def get_config() -> Config:
    """Get the global configuration instance."""
    global _config
    if _config is None:
        _config = Config()
        errors = _config.validate()
        if errors:
            raise ValueError(f"Configuration errors: {errors}")
    return _config


def reload_config() -> Config:
    """Reload configuration from environment."""
    global _config
    _config = None
    return get_config()
