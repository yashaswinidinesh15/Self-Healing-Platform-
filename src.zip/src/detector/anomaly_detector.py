"""
Anomaly Detection Module
Uses Isolation Forest for multi-dimensional anomaly detection on cluster metrics.
"""

import logging
import pickle
from pathlib import Path
from datetime import datetime
from typing import List, Optional, Tuple, Dict, Any
from dataclasses import dataclass, field
from enum import Enum

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

from src.config import get_config
from src.collector.metrics_collector import ClusterMetrics

logger = logging.getLogger(__name__)


class AnomalySeverity(Enum):
    """Anomaly severity levels."""
    NORMAL = "normal"
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class AnomalyResult:
    """Result of anomaly detection analysis."""
    timestamp: datetime
    anomaly_score: float  # 0-1, higher = more anomalous
    is_anomaly: bool
    severity: AnomalySeverity
    contributing_factors: List[str]
    confidence: float
    raw_scores: Dict[str, float] = field(default_factory=dict)
    recommendations: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "anomaly_score": round(self.anomaly_score, 4),
            "is_anomaly": self.is_anomaly,
            "severity": self.severity.value,
            "contributing_factors": self.contributing_factors,
            "confidence": round(self.confidence, 4),
            "raw_scores": {k: round(v, 4) for k, v in self.raw_scores.items()},
            "recommendations": self.recommendations
        }


class FeatureEngineer:
    """
    Feature engineering for anomaly detection.
    Transforms raw metrics into features suitable for ML models.
    """
    
    FEATURE_NAMES = [
        "cpu_usage_percent",
        "memory_usage_percent",
        "error_rate_per_second",
        "latency_p99_ms",
        "request_rate_per_second"
    ]
    
    def __init__(self):
        self.scaler = StandardScaler()
        self.is_fitted = False
        self.feature_means = {}
        self.feature_stds = {}
    
    def fit(self, df: pd.DataFrame) -> "FeatureEngineer":
        """Fit the scaler on historical data."""
        features = df[self.FEATURE_NAMES].values
        self.scaler.fit(features)
        self.is_fitted = True
        
        # Store statistics for interpretability
        for i, name in enumerate(self.FEATURE_NAMES):
            self.feature_means[name] = self.scaler.mean_[i]
            self.feature_stds[name] = self.scaler.scale_[i]
        
        logger.info(f"FeatureEngineer fitted on {len(df)} samples")
        return self
    
    def transform(self, metrics: ClusterMetrics) -> np.ndarray:
        """Transform metrics to feature vector."""
        raw = np.array([[
            metrics.cpu_usage_percent,
            metrics.memory_usage_percent,
            metrics.error_rate_per_second,
            metrics.latency_p99_ms,
            metrics.request_rate_per_second
        ]])
        
        if self.is_fitted:
            return self.scaler.transform(raw)
        return raw
    
    def get_feature_contributions(
        self, 
        metrics: ClusterMetrics
    ) -> Dict[str, float]:
        """
        Calculate how much each feature contributes to anomaly.
        Uses z-score based contribution.
        """
        contributions = {}
        
        for name in self.FEATURE_NAMES:
            value = getattr(metrics, name)
            if name in self.feature_means and self.feature_stds.get(name, 0) > 0:
                z_score = abs(value - self.feature_means[name]) / self.feature_stds[name]
                contributions[name] = min(z_score / 3, 1.0)  # Normalize to 0-1
            else:
                contributions[name] = 0.0
        
        return contributions


class AnomalyDetector:
    """
    Isolation Forest based anomaly detector for infrastructure metrics.
    
    Features:
    - Multi-dimensional anomaly scoring
    - Incremental learning support
    - Feature contribution analysis
    - Configurable thresholds
    """
    
    def __init__(self, model_path: Optional[str] = None):
        self.config = get_config()
        self.model_path = model_path or self.config.anomaly.model_path
        
        # Initialize model
        self.model = IsolationForest(
            contamination=self.config.anomaly.contamination,
            n_estimators=self.config.anomaly.n_estimators,
            random_state=42,
            n_jobs=-1,
            warm_start=True  # Enable incremental learning
        )
        
        self.feature_engineer = FeatureEngineer()
        self.is_trained = False
        self.training_samples = 0
        
        # Try to load pre-trained model
        self._load_model()
        
        logger.info("AnomalyDetector initialized")
    
    def _load_model(self) -> bool:
        """Load pre-trained model from disk."""
        model_file = Path(self.model_path)
        if model_file.exists():
            try:
                with open(model_file, "rb") as f:
                    saved = pickle.load(f)
                    self.model = saved["model"]
                    self.feature_engineer = saved["feature_engineer"]
                    self.is_trained = True
                    self.training_samples = saved.get("training_samples", 0)
                logger.info(f"Loaded pre-trained model from {self.model_path}")
                return True
            except Exception as e:
                logger.warning(f"Failed to load model: {e}")
        return False
    
    def save_model(self) -> None:
        """Save trained model to disk."""
        model_file = Path(self.model_path)
        model_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(model_file, "wb") as f:
            pickle.dump({
                "model": self.model,
                "feature_engineer": self.feature_engineer,
                "training_samples": self.training_samples
            }, f)
        
        logger.info(f"Model saved to {self.model_path}")
    
    def train(self, df: pd.DataFrame) -> "AnomalyDetector":
        """
        Train the anomaly detection model on historical data.
        
        Args:
            df: DataFrame with metric columns
            
        Returns:
            Self for chaining
        """
        logger.info(f"Training anomaly detector on {len(df)} samples")
        
        # Fit feature engineer
        self.feature_engineer.fit(df)
        
        # Prepare features
        features = df[FeatureEngineer.FEATURE_NAMES].values
        scaled_features = self.feature_engineer.scaler.transform(features)
        
        # Train isolation forest
        self.model.fit(scaled_features)
        self.is_trained = True
        self.training_samples = len(df)
        
        # Save model
        self.save_model()
        
        logger.info("Anomaly detector training complete")
        return self
    
    def detect(self, metrics: ClusterMetrics) -> AnomalyResult:
        """
        Detect anomalies in current metrics.
        
        Args:
            metrics: Current cluster metrics
            
        Returns:
            AnomalyResult with detection details
        """
        if not self.is_trained:
            logger.warning("Model not trained, using default thresholds")
            return self._detect_threshold_based(metrics)
        
        # Transform features
        features = self.feature_engineer.transform(metrics)
        
        # Get anomaly score (-1 to 1, convert to 0-1 where higher = more anomalous)
        raw_score = self.model.decision_function(features)[0]
        anomaly_score = 1 - (raw_score + 0.5)  # Normalize to 0-1
        anomaly_score = max(0, min(1, anomaly_score))  # Clamp
        
        # Determine severity
        if anomaly_score >= self.config.anomaly.threshold_critical:
            severity = AnomalySeverity.CRITICAL
            is_anomaly = True
        elif anomaly_score >= self.config.anomaly.threshold_warning:
            severity = AnomalySeverity.WARNING
            is_anomaly = True
        else:
            severity = AnomalySeverity.NORMAL
            is_anomaly = False
        
        # Get contributing factors
        contributions = self.feature_engineer.get_feature_contributions(metrics)
        contributing_factors = [
            name for name, score in sorted(
                contributions.items(), 
                key=lambda x: x[1], 
                reverse=True
            )
            if score > 0.5  # Only significant contributors
        ][:3]  # Top 3
        
        # Calculate confidence based on model certainty
        confidence = min(abs(raw_score) * 2, 1.0)
        
        # Generate recommendations
        recommendations = self._generate_recommendations(
            metrics, contributing_factors, severity
        )
        
        result = AnomalyResult(
            timestamp=metrics.timestamp,
            anomaly_score=anomaly_score,
            is_anomaly=is_anomaly,
            severity=severity,
            contributing_factors=contributing_factors,
            confidence=confidence,
            raw_scores=contributions,
            recommendations=recommendations
        )
        
        logger.info(
            f"Anomaly detection: score={anomaly_score:.3f}, "
            f"severity={severity.value}, factors={contributing_factors}"
        )
        
        return result
    
    def _detect_threshold_based(self, metrics: ClusterMetrics) -> AnomalyResult:
        """Fallback threshold-based detection when model isn't trained."""
        anomalies = []
        
        # Simple threshold checks
        if metrics.cpu_usage_percent > 85:
            anomalies.append("cpu_usage_percent")
        if metrics.memory_usage_percent > 90:
            anomalies.append("memory_usage_percent")
        if metrics.error_rate_per_second > 5:
            anomalies.append("error_rate_per_second")
        if metrics.latency_p99_ms > 1000:
            anomalies.append("latency_p99_ms")
        
        is_anomaly = len(anomalies) > 0
        severity = (
            AnomalySeverity.CRITICAL if len(anomalies) >= 2
            else AnomalySeverity.WARNING if is_anomaly
            else AnomalySeverity.NORMAL
        )
        
        return AnomalyResult(
            timestamp=metrics.timestamp,
            anomaly_score=len(anomalies) / 4,
            is_anomaly=is_anomaly,
            severity=severity,
            contributing_factors=anomalies,
            confidence=0.6,  # Lower confidence for threshold-based
            recommendations=self._generate_recommendations(metrics, anomalies, severity)
        )
    
    def _generate_recommendations(
        self, 
        metrics: ClusterMetrics, 
        factors: List[str],
        severity: AnomalySeverity
    ) -> List[str]:
        """Generate actionable recommendations based on anomaly."""
        recommendations = []
        
        if "cpu_usage_percent" in factors:
            if metrics.cpu_usage_percent > 90:
                recommendations.append("CRITICAL: Scale out pods immediately (HPA)")
            else:
                recommendations.append("Consider scaling pods or optimizing CPU-intensive workloads")
        
        if "memory_usage_percent" in factors:
            if metrics.memory_usage_percent > 95:
                recommendations.append("CRITICAL: Potential OOM - restart memory-heavy pods")
            else:
                recommendations.append("Monitor for memory leaks, consider increasing limits")
        
        if "error_rate_per_second" in factors:
            recommendations.append("Investigate error logs, check recent deployments")
        
        if "latency_p99_ms" in factors:
            recommendations.append("Check downstream dependencies, database performance")
        
        if severity == AnomalySeverity.CRITICAL and not recommendations:
            recommendations.append("Multiple metrics degraded - consider rollback")
        
        return recommendations
    
    def update(self, df: pd.DataFrame) -> None:
        """
        Incrementally update the model with new data.
        Uses warm start for efficient updates.
        """
        if not self.is_trained:
            self.train(df)
            return
        
        # Re-fit scaler with combined data
        features = df[FeatureEngineer.FEATURE_NAMES].values
        
        # Partial fit (warm start)
        self.model.n_estimators += 10  # Add more trees
        scaled_features = self.feature_engineer.scaler.transform(features)
        self.model.fit(scaled_features)
        
        self.training_samples += len(df)
        self.save_model()
        
        logger.info(f"Model updated with {len(df)} new samples")


# Singleton instance
_detector: Optional[AnomalyDetector] = None


def get_detector() -> AnomalyDetector:
    """Get the global AnomalyDetector instance."""
    global _detector
    if _detector is None:
        _detector = AnomalyDetector()
    return _detector
