"""
Auto-Remediation Module
Executes safe, automated remediation actions based on anomalies and predictions.
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod
import asyncio

from kubernetes import client, config
from kubernetes.client.rest import ApiException

from src.config import get_config
from src.detector.anomaly_detector import AnomalyResult, AnomalySeverity
from src.predictor.failure_predictor import FailurePrediction, FailureType

logger = logging.getLogger(__name__)


class ActionType(Enum):
    """Types of remediation actions."""
    POD_RESTART = "pod_restart"
    HPA_SCALE = "hpa_scale"
    ROLLING_RESTART = "rolling_restart"
    DEPLOYMENT_ROLLBACK = "deployment_rollback"
    NODE_CORDON = "node_cordon"
    CONFIG_RELOAD = "config_reload"
    ALERT_ONLY = "alert_only"


class ActionStatus(Enum):
    """Status of remediation action."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"
    BLOCKED = "blocked"  # Blocked by safety controls


@dataclass
class RemediationAction:
    """Definition of a remediation action."""
    action_type: ActionType
    target_namespace: str
    target_name: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    reason: str = ""
    priority: int = 1  # Lower = higher priority
    
    @property
    def id(self) -> str:
        return f"{self.action_type.value}:{self.target_namespace}/{self.target_name}"


@dataclass
class ActionResult:
    """Result of executing a remediation action."""
    action: RemediationAction
    status: ActionStatus
    started_at: datetime
    completed_at: Optional[datetime] = None
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def duration_seconds(self) -> Optional[float]:
        if self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "action_type": self.action.action_type.value,
            "target": f"{self.action.target_namespace}/{self.action.target_name}",
            "status": self.status.value,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "duration_seconds": self.duration_seconds,
            "message": self.message,
            "reason": self.action.reason
        }


class SafetyController:
    """
    Enforces safety controls on remediation actions.
    Prevents runaway automation and protects critical systems.
    """
    
    def __init__(self):
        self.config = get_config()
        self.action_history: Dict[str, List[datetime]] = {}
        self.cooldown_until: Dict[str, datetime] = {}
    
    def can_execute(self, action: RemediationAction) -> tuple[bool, str]:
        """
        Check if action can be executed safely.
        
        Returns:
            Tuple of (allowed, reason)
        """
        # Check dry run mode
        if self.config.remediation.dry_run:
            return False, "Dry run mode enabled"
        
        # Check if remediation is enabled
        if not self.config.remediation.enabled:
            return False, "Remediation disabled"
        
        # Check excluded namespaces
        if action.target_namespace in self.config.kubernetes.excluded_namespaces:
            return False, f"Namespace {action.target_namespace} is excluded"
        
        # Check cooldown
        if action.id in self.cooldown_until:
            if datetime.utcnow() < self.cooldown_until[action.id]:
                remaining = (self.cooldown_until[action.id] - datetime.utcnow()).seconds
                return False, f"Cooldown active: {remaining}s remaining"
        
        # Check rate limits
        if not self._check_rate_limit(action):
            return False, f"Rate limit exceeded for {action.action_type.value}"
        
        # Check global action limit
        total_actions = sum(len(h) for h in self.action_history.values())
        if total_actions >= self.config.remediation.max_actions_per_hour:
            return False, "Global hourly action limit reached"
        
        return True, "Allowed"
    
    def _check_rate_limit(self, action: RemediationAction) -> bool:
        """Check action-specific rate limits."""
        action_key = f"{action.action_type.value}:{action.target_name}"
        now = datetime.utcnow()
        hour_ago = now - timedelta(hours=1)
        
        # Clean old history
        if action_key in self.action_history:
            self.action_history[action_key] = [
                t for t in self.action_history[action_key] if t > hour_ago
            ]
        else:
            self.action_history[action_key] = []
        
        # Check limits based on action type
        current_count = len(self.action_history[action_key])
        
        limits = {
            ActionType.POD_RESTART: self.config.remediation.pod_restart_max_per_hour,
            ActionType.HPA_SCALE: 5,
            ActionType.ROLLING_RESTART: 2,
            ActionType.DEPLOYMENT_ROLLBACK: 2,
            ActionType.NODE_CORDON: 3
        }
        
        limit = limits.get(action.action_type, 10)
        return current_count < limit
    
    def record_action(self, action: RemediationAction) -> None:
        """Record that an action was executed."""
        action_key = f"{action.action_type.value}:{action.target_name}"
        
        if action_key not in self.action_history:
            self.action_history[action_key] = []
        
        self.action_history[action_key].append(datetime.utcnow())
        
        # Set cooldown
        self.cooldown_until[action.id] = (
            datetime.utcnow() + 
            timedelta(seconds=self.config.remediation.cooldown_seconds)
        )


class BaseActionExecutor(ABC):
    """Base class for action executors."""
    
    @abstractmethod
    async def execute(self, action: RemediationAction) -> ActionResult:
        """Execute the remediation action."""
        pass


class PodRestartExecutor(BaseActionExecutor):
    """Executes pod restart actions."""
    
    def __init__(self, k8s_client: client.CoreV1Api):
        self.k8s = k8s_client
    
    async def execute(self, action: RemediationAction) -> ActionResult:
        started_at = datetime.utcnow()
        
        try:
            # Delete pod (Kubernetes will recreate it)
            self.k8s.delete_namespaced_pod(
                name=action.target_name,
                namespace=action.target_namespace,
                body=client.V1DeleteOptions(
                    grace_period_seconds=30
                )
            )
            
            return ActionResult(
                action=action,
                status=ActionStatus.SUCCESS,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                message=f"Pod {action.target_name} deleted for restart"
            )
            
        except ApiException as e:
            return ActionResult(
                action=action,
                status=ActionStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                message=f"Failed to restart pod: {e.reason}",
                details={"error": str(e)}
            )


class HPAScaleExecutor(BaseActionExecutor):
    """Executes HPA scaling actions."""
    
    def __init__(self, k8s_client: client.AutoscalingV1Api):
        self.k8s = k8s_client
        self.config = get_config()
    
    async def execute(self, action: RemediationAction) -> ActionResult:
        started_at = datetime.utcnow()
        
        try:
            # Get current HPA
            hpa = self.k8s.read_namespaced_horizontal_pod_autoscaler(
                name=action.target_name,
                namespace=action.target_namespace
            )
            
            current_max = hpa.spec.max_replicas
            scale_percent = action.parameters.get(
                "scale_percent", 
                self.config.remediation.hpa_scale_up_percent
            )
            
            # Calculate new max
            new_max = min(
                int(current_max * (1 + scale_percent / 100)),
                self.config.remediation.hpa_scale_max_replicas
            )
            
            if new_max <= current_max:
                return ActionResult(
                    action=action,
                    status=ActionStatus.SKIPPED,
                    started_at=started_at,
                    completed_at=datetime.utcnow(),
                    message=f"HPA already at max ({current_max})"
                )
            
            # Update HPA
            hpa.spec.max_replicas = new_max
            self.k8s.patch_namespaced_horizontal_pod_autoscaler(
                name=action.target_name,
                namespace=action.target_namespace,
                body=hpa
            )
            
            return ActionResult(
                action=action,
                status=ActionStatus.SUCCESS,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                message=f"HPA max replicas: {current_max} -> {new_max}",
                details={"old_max": current_max, "new_max": new_max}
            )
            
        except ApiException as e:
            return ActionResult(
                action=action,
                status=ActionStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                message=f"Failed to scale HPA: {e.reason}"
            )


class RollingRestartExecutor(BaseActionExecutor):
    """Executes deployment rolling restart."""
    
    def __init__(self, k8s_client: client.AppsV1Api):
        self.k8s = k8s_client
    
    async def execute(self, action: RemediationAction) -> ActionResult:
        started_at = datetime.utcnow()
        
        try:
            # Patch deployment with restart annotation
            patch = {
                "spec": {
                    "template": {
                        "metadata": {
                            "annotations": {
                                "selfhealstack.io/restartedAt": datetime.utcnow().isoformat()
                            }
                        }
                    }
                }
            }
            
            self.k8s.patch_namespaced_deployment(
                name=action.target_name,
                namespace=action.target_namespace,
                body=patch
            )
            
            return ActionResult(
                action=action,
                status=ActionStatus.SUCCESS,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                message=f"Rolling restart initiated for {action.target_name}"
            )
            
        except ApiException as e:
            return ActionResult(
                action=action,
                status=ActionStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                message=f"Failed to restart deployment: {e.reason}"
            )


class DeploymentRollbackExecutor(BaseActionExecutor):
    """Executes deployment rollback."""
    
    def __init__(self, k8s_client: client.AppsV1Api):
        self.k8s = k8s_client
        self.config = get_config()
    
    async def execute(self, action: RemediationAction) -> ActionResult:
        started_at = datetime.utcnow()
        
        # Check if approval required
        if self.config.remediation.rollback_require_approval:
            return ActionResult(
                action=action,
                status=ActionStatus.BLOCKED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                message="Rollback requires manual approval"
            )
        
        try:
            # Get deployment
            deployment = self.k8s.read_namespaced_deployment(
                name=action.target_name,
                namespace=action.target_namespace
            )
            
            # Get revision history
            revision = action.parameters.get("revision")
            
            if not revision:
                # Rollback to previous revision
                # In practice, you'd use `kubectl rollout undo`
                # Here we simulate by patching
                pass
            
            return ActionResult(
                action=action,
                status=ActionStatus.SUCCESS,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                message=f"Rollback initiated for {action.target_name}"
            )
            
        except ApiException as e:
            return ActionResult(
                action=action,
                status=ActionStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                message=f"Failed to rollback: {e.reason}"
            )


class AutoRemediator:
    """
    Orchestrates automated remediation of infrastructure issues.
    
    Features:
    - Safe, controlled action execution
    - Rate limiting and cooldowns
    - Audit logging
    - Support for multiple action types
    """
    
    def __init__(self):
        self.config = get_config()
        self.safety = SafetyController()
        
        # Initialize Kubernetes client
        try:
            if self.config.kubernetes.in_cluster:
                config.load_incluster_config()
            else:
                config.load_kube_config(
                    config_file=self.config.kubernetes.kubeconfig_path
                )
            
            self.core_v1 = client.CoreV1Api()
            self.apps_v1 = client.AppsV1Api()
            self.autoscaling_v1 = client.AutoscalingV1Api()
            self.k8s_available = True
            
        except Exception as e:
            logger.warning(f"Kubernetes client not available: {e}")
            self.k8s_available = False
        
        # Initialize executors
        if self.k8s_available:
            self.executors = {
                ActionType.POD_RESTART: PodRestartExecutor(self.core_v1),
                ActionType.HPA_SCALE: HPAScaleExecutor(self.autoscaling_v1),
                ActionType.ROLLING_RESTART: RollingRestartExecutor(self.apps_v1),
                ActionType.DEPLOYMENT_ROLLBACK: DeploymentRollbackExecutor(self.apps_v1)
            }
        else:
            self.executors = {}
        
        self.action_history: List[ActionResult] = []
        
        logger.info("AutoRemediator initialized")
    
    def plan_action(
        self, 
        anomaly: Optional[AnomalyResult] = None,
        prediction: Optional[FailurePrediction] = None
    ) -> Optional[RemediationAction]:
        """
        Plan remediation action based on anomaly or prediction.
        
        Returns:
            RemediationAction if action needed, None otherwise
        """
        if anomaly and anomaly.severity == AnomalySeverity.CRITICAL:
            return self._plan_from_anomaly(anomaly)
        
        if prediction and prediction.is_actionable:
            return self._plan_from_prediction(prediction)
        
        return None
    
    def _plan_from_anomaly(self, anomaly: AnomalyResult) -> Optional[RemediationAction]:
        """Plan action based on anomaly detection."""
        namespace = self.config.kubernetes.namespace
        
        # Map contributing factors to actions
        if "memory_usage_percent" in anomaly.contributing_factors:
            return RemediationAction(
                action_type=ActionType.ROLLING_RESTART,
                target_namespace=namespace,
                target_name="app",  # Would be detected dynamically
                reason=f"Memory anomaly detected: {anomaly.anomaly_score:.2f}",
                priority=1
            )
        
        if "cpu_usage_percent" in anomaly.contributing_factors:
            return RemediationAction(
                action_type=ActionType.HPA_SCALE,
                target_namespace=namespace,
                target_name="app",
                parameters={"scale_percent": 50},
                reason=f"CPU anomaly detected: {anomaly.anomaly_score:.2f}",
                priority=1
            )
        
        if "error_rate_per_second" in anomaly.contributing_factors:
            return RemediationAction(
                action_type=ActionType.DEPLOYMENT_ROLLBACK,
                target_namespace=namespace,
                target_name="app",
                reason="Error rate spike detected",
                priority=1
            )
        
        return None
    
    def _plan_from_prediction(
        self, 
        prediction: FailurePrediction
    ) -> Optional[RemediationAction]:
        """Plan action based on failure prediction."""
        namespace = self.config.kubernetes.namespace
        
        action_map = {
            FailureType.CPU_EXHAUSTION: (ActionType.HPA_SCALE, {"scale_percent": 50}),
            FailureType.MEMORY_EXHAUSTION: (ActionType.ROLLING_RESTART, {}),
            FailureType.ERROR_SPIKE: (ActionType.DEPLOYMENT_ROLLBACK, {}),
            FailureType.CASCADE_FAILURE: (ActionType.DEPLOYMENT_ROLLBACK, {}),
            FailureType.LATENCY_DEGRADATION: (ActionType.HPA_SCALE, {"scale_percent": 30})
        }
        
        if prediction.failure_type in action_map:
            action_type, params = action_map[prediction.failure_type]
            return RemediationAction(
                action_type=action_type,
                target_namespace=namespace,
                target_name="app",
                parameters=params,
                reason=f"Predicted {prediction.failure_type.value}: {prediction.probability:.0%}",
                priority=2
            )
        
        return None
    
    async def execute(self, action: RemediationAction) -> ActionResult:
        """
        Execute a remediation action with safety checks.
        """
        # Safety check
        allowed, reason = self.safety.can_execute(action)
        
        if not allowed:
            logger.warning(f"Action blocked: {reason}")
            result = ActionResult(
                action=action,
                status=ActionStatus.BLOCKED,
                started_at=datetime.utcnow(),
                completed_at=datetime.utcnow(),
                message=reason
            )
            self.action_history.append(result)
            return result
        
        # Check if K8s is available
        if not self.k8s_available:
            logger.warning("Kubernetes not available, simulating action")
            result = ActionResult(
                action=action,
                status=ActionStatus.SUCCESS,
                started_at=datetime.utcnow(),
                completed_at=datetime.utcnow(),
                message="[SIMULATED] Action would be executed"
            )
            self.action_history.append(result)
            return result
        
        # Get executor
        executor = self.executors.get(action.action_type)
        if not executor:
            result = ActionResult(
                action=action,
                status=ActionStatus.FAILED,
                started_at=datetime.utcnow(),
                completed_at=datetime.utcnow(),
                message=f"No executor for {action.action_type.value}"
            )
            self.action_history.append(result)
            return result
        
        # Execute action
        logger.info(f"Executing action: {action.id}")
        result = await executor.execute(action)
        
        # Record action
        if result.status == ActionStatus.SUCCESS:
            self.safety.record_action(action)
        
        self.action_history.append(result)
        
        logger.info(
            f"Action completed: {action.id} -> {result.status.value}: {result.message}"
        )
        
        return result
    
    def get_action_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent action history."""
        return [a.to_dict() for a in self.action_history[-limit:]]


# Singleton instance
_remediator: Optional[AutoRemediator] = None


def get_remediator() -> AutoRemediator:
    """Get the global AutoRemediator instance."""
    global _remediator
    if _remediator is None:
        _remediator = AutoRemediator()
    return _remediator
