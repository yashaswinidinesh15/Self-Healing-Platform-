"""
Prometheus Metrics Collector
Fetches and processes metrics from Prometheus for anomaly detection.
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
import httpx
import pandas as pd
import numpy as np
from tenacity import retry, stop_after_attempt, wait_exponential

from src.config import get_config

logger = logging.getLogger(__name__)


@dataclass
class MetricPoint:
    """Single metric data point."""
    timestamp: datetime
    value: float
    labels: Dict[str, str] = field(default_factory=dict)


@dataclass
class MetricSeries:
    """Time series of metric data."""
    name: str
    points: List[MetricPoint]
    
    def to_dataframe(self) -> pd.DataFrame:
        """Convert to pandas DataFrame."""
        data = [
            {"timestamp": p.timestamp, "value": p.value, **p.labels}
            for p in self.points
        ]
        return pd.DataFrame(data)
    
    @property
    def latest_value(self) -> Optional[float]:
        """Get the most recent value."""
        return self.points[-1].value if self.points else None


@dataclass
class ClusterMetrics:
    """Aggregated cluster metrics for a single timestamp."""
    timestamp: datetime
    cpu_usage_percent: float
    memory_usage_percent: float
    error_rate_per_second: float
    latency_p50_ms: float
    latency_p95_ms: float
    latency_p99_ms: float
    request_rate_per_second: float
    pod_restart_count: int
    node_count: int
    pod_count: int
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "cpu_usage_percent": self.cpu_usage_percent,
            "memory_usage_percent": self.memory_usage_percent,
            "error_rate_per_second": self.error_rate_per_second,
            "latency_p50_ms": self.latency_p50_ms,
            "latency_p95_ms": self.latency_p95_ms,
            "latency_p99_ms": self.latency_p99_ms,
            "request_rate_per_second": self.request_rate_per_second,
            "pod_restart_count": self.pod_restart_count,
            "node_count": self.node_count,
            "pod_count": self.pod_count
        }
    
    def to_feature_vector(self) -> np.ndarray:
        """Convert to numpy array for ML models."""
        return np.array([
            self.cpu_usage_percent,
            self.memory_usage_percent,
            self.error_rate_per_second,
            self.latency_p99_ms,
            self.request_rate_per_second
        ])


class PromQLQueries:
    """PromQL query definitions for Kubernetes metrics."""
    
    # CPU metrics
    CPU_USAGE = '''
        100 * (
            1 - avg(rate(node_cpu_seconds_total{mode="idle"}[5m]))
        )
    '''
    
    CPU_BY_NAMESPACE = '''
        sum(rate(container_cpu_usage_seconds_total{namespace!=""}[5m])) by (namespace)
        / sum(machine_cpu_cores) * 100
    '''
    
    # Memory metrics
    MEMORY_USAGE = '''
        100 * (
            1 - (
                sum(node_memory_MemAvailable_bytes) 
                / sum(node_memory_MemTotal_bytes)
            )
        )
    '''
    
    MEMORY_BY_POD = '''
        sum(container_memory_usage_bytes{namespace!=""}) by (pod, namespace)
        / sum(container_spec_memory_limit_bytes{namespace!=""}) by (pod, namespace) * 100
    '''
    
    # Error rates
    ERROR_RATE = '''
        sum(rate(http_requests_total{status=~"5.."}[5m]))
        / sum(rate(http_requests_total[5m])) * 100
    '''
    
    ERROR_RATE_BY_SERVICE = '''
        sum(rate(http_requests_total{status=~"5.."}[5m])) by (service)
    '''
    
    # Latency metrics
    LATENCY_P50 = '''
        histogram_quantile(0.50, 
            sum(rate(http_request_duration_seconds_bucket[5m])) by (le)
        ) * 1000
    '''
    
    LATENCY_P95 = '''
        histogram_quantile(0.95, 
            sum(rate(http_request_duration_seconds_bucket[5m])) by (le)
        ) * 1000
    '''
    
    LATENCY_P99 = '''
        histogram_quantile(0.99, 
            sum(rate(http_request_duration_seconds_bucket[5m])) by (le)
        ) * 1000
    '''
    
    # Request rate
    REQUEST_RATE = '''
        sum(rate(http_requests_total[5m]))
    '''
    
    # Pod metrics
    POD_RESTARTS = '''
        sum(increase(kube_pod_container_status_restarts_total[1h]))
    '''
    
    POD_COUNT = '''
        count(kube_pod_status_phase{phase="Running"})
    '''
    
    # Node metrics
    NODE_COUNT = '''
        count(kube_node_info)
    '''
    
    NODE_PRESSURE = '''
        sum(kube_node_status_condition{condition=~"MemoryPressure|DiskPressure|PIDPressure", status="true"})
    '''


class MetricsCollector:
    """
    Collects metrics from Prometheus and transforms them for analysis.
    
    Features:
    - Automatic retry with exponential backoff
    - Connection pooling for performance
    - Metric aggregation and transformation
    - Historical data fetching for ML training
    """
    
    def __init__(self):
        self.config = get_config()
        self.base_url = self.config.prometheus.url
        self.timeout = self.config.prometheus.timeout_seconds
        self.client = httpx.Client(
            base_url=self.base_url,
            timeout=self.timeout,
            follow_redirects=True
        )
        self.queries = PromQLQueries()
        logger.info(f"MetricsCollector initialized with Prometheus at {self.base_url}")
    
    def __del__(self):
        """Cleanup HTTP client."""
        if hasattr(self, 'client'):
            self.client.close()
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10)
    )
    def _query_instant(self, query: str) -> Optional[float]:
        """Execute instant query and return single value."""
        try:
            response = self.client.get(
                "/api/v1/query",
                params={"query": query.strip()}
            )
            response.raise_for_status()
            data = response.json()
            
            if data["status"] != "success":
                logger.error(f"Prometheus query failed: {data}")
                return None
            
            results = data.get("data", {}).get("result", [])
            if not results:
                return None
            
            # Return first result value
            value = float(results[0]["value"][1])
            return value if not np.isnan(value) and not np.isinf(value) else None
            
        except Exception as e:
            logger.error(f"Error executing query: {e}")
            raise
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10)
    )
    def _query_range(
        self, 
        query: str, 
        start: datetime, 
        end: datetime, 
        step: str = "60s"
    ) -> List[MetricPoint]:
        """Execute range query and return time series."""
        try:
            response = self.client.get(
                "/api/v1/query_range",
                params={
                    "query": query.strip(),
                    "start": start.timestamp(),
                    "end": end.timestamp(),
                    "step": step
                }
            )
            response.raise_for_status()
            data = response.json()
            
            if data["status"] != "success":
                logger.error(f"Prometheus range query failed: {data}")
                return []
            
            results = data.get("data", {}).get("result", [])
            if not results:
                return []
            
            # Convert to MetricPoints
            points = []
            for ts, val in results[0].get("values", []):
                value = float(val)
                if not np.isnan(value) and not np.isinf(value):
                    points.append(MetricPoint(
                        timestamp=datetime.fromtimestamp(ts),
                        value=value,
                        labels=results[0].get("metric", {})
                    ))
            
            return points
            
        except Exception as e:
            logger.error(f"Error executing range query: {e}")
            raise
    
    def fetch_current_metrics(self) -> ClusterMetrics:
        """
        Fetch current cluster metrics snapshot.
        
        Returns:
            ClusterMetrics object with all current values
        """
        logger.debug("Fetching current cluster metrics")
        
        # Fetch all metrics in parallel (could use asyncio for better perf)
        cpu = self._query_instant(self.queries.CPU_USAGE) or 0.0
        memory = self._query_instant(self.queries.MEMORY_USAGE) or 0.0
        error_rate = self._query_instant(self.queries.ERROR_RATE) or 0.0
        latency_p50 = self._query_instant(self.queries.LATENCY_P50) or 0.0
        latency_p95 = self._query_instant(self.queries.LATENCY_P95) or 0.0
        latency_p99 = self._query_instant(self.queries.LATENCY_P99) or 0.0
        request_rate = self._query_instant(self.queries.REQUEST_RATE) or 0.0
        pod_restarts = self._query_instant(self.queries.POD_RESTARTS) or 0
        node_count = self._query_instant(self.queries.NODE_COUNT) or 0
        pod_count = self._query_instant(self.queries.POD_COUNT) or 0
        
        metrics = ClusterMetrics(
            timestamp=datetime.utcnow(),
            cpu_usage_percent=cpu,
            memory_usage_percent=memory,
            error_rate_per_second=error_rate,
            latency_p50_ms=latency_p50,
            latency_p95_ms=latency_p95,
            latency_p99_ms=latency_p99,
            request_rate_per_second=request_rate,
            pod_restart_count=int(pod_restarts),
            node_count=int(node_count),
            pod_count=int(pod_count)
        )
        
        logger.info(
            f"Metrics collected: CPU={cpu:.1f}%, Memory={memory:.1f}%, "
            f"Errors={error_rate:.2f}/s, P99={latency_p99:.0f}ms"
        )
        
        return metrics
    
    def fetch_historical_metrics(
        self, 
        duration_minutes: int = 60,
        step_seconds: int = 60
    ) -> pd.DataFrame:
        """
        Fetch historical metrics for ML model training/prediction.
        
        Args:
            duration_minutes: How far back to fetch
            step_seconds: Resolution of data points
            
        Returns:
            DataFrame with historical metrics
        """
        end = datetime.utcnow()
        start = end - timedelta(minutes=duration_minutes)
        step = f"{step_seconds}s"
        
        logger.info(f"Fetching {duration_minutes} minutes of historical data")
        
        # Fetch each metric series
        cpu_series = self._query_range(self.queries.CPU_USAGE, start, end, step)
        memory_series = self._query_range(self.queries.MEMORY_USAGE, start, end, step)
        error_series = self._query_range(self.queries.ERROR_RATE, start, end, step)
        latency_series = self._query_range(self.queries.LATENCY_P99, start, end, step)
        request_series = self._query_range(self.queries.REQUEST_RATE, start, end, step)
        
        # Build DataFrame
        data = []
        timestamps = [p.timestamp for p in cpu_series]
        
        for i, ts in enumerate(timestamps):
            data.append({
                "timestamp": ts,
                "cpu_usage_percent": cpu_series[i].value if i < len(cpu_series) else 0,
                "memory_usage_percent": memory_series[i].value if i < len(memory_series) else 0,
                "error_rate_per_second": error_series[i].value if i < len(error_series) else 0,
                "latency_p99_ms": latency_series[i].value if i < len(latency_series) else 0,
                "request_rate_per_second": request_series[i].value if i < len(request_series) else 0
            })
        
        df = pd.DataFrame(data)
        logger.info(f"Fetched {len(df)} historical data points")
        
        return df
    
    def get_pod_metrics(self, namespace: str = None) -> List[Dict[str, Any]]:
        """Get metrics for individual pods."""
        ns_filter = f'namespace="{namespace}"' if namespace else 'namespace!=""'
        
        query = f'''
            sum(rate(container_cpu_usage_seconds_total{{{ns_filter}}}[5m])) by (pod, namespace)
        '''
        
        try:
            response = self.client.get(
                "/api/v1/query",
                params={"query": query.strip()}
            )
            response.raise_for_status()
            data = response.json()
            
            results = []
            for item in data.get("data", {}).get("result", []):
                results.append({
                    "pod": item["metric"].get("pod", "unknown"),
                    "namespace": item["metric"].get("namespace", "unknown"),
                    "cpu_usage": float(item["value"][1])
                })
            
            return results
            
        except Exception as e:
            logger.error(f"Error fetching pod metrics: {e}")
            return []
    
    def health_check(self) -> bool:
        """Check Prometheus connectivity."""
        try:
            response = self.client.get("/api/v1/status/config")
            return response.status_code == 200
        except Exception:
            return False


# Singleton instance
_collector: Optional[MetricsCollector] = None


def get_collector() -> MetricsCollector:
    """Get the global MetricsCollector instance."""
    global _collector
    if _collector is None:
        _collector = MetricsCollector()
    return _collector
