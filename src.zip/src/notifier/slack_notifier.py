"""
Slack Notification Module
Sends formatted alerts and audit logs to Slack channels.
"""

import logging
from datetime import datetime
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from enum import Enum

import httpx

from src.config import get_config
from src.detector.anomaly_detector import AnomalyResult, AnomalySeverity
from src.predictor.failure_predictor import FailurePrediction
from src.remediator.auto_remediator import ActionResult, ActionStatus

logger = logging.getLogger(__name__)


class AlertLevel(Enum):
    """Alert severity levels for Slack formatting."""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    SUCCESS = "success"


@dataclass
class SlackMessage:
    """Slack message structure."""
    channel: str
    text: str
    blocks: List[Dict[str, Any]]
    attachments: List[Dict[str, Any]] = None


class SlackNotifier:
    """
    Sends notifications to Slack with rich formatting.
    
    Features:
    - Formatted anomaly alerts
    - Prediction warnings
    - Remediation action logs
    - Audit trail
    """
    
    # Color mapping for alert levels
    COLORS = {
        AlertLevel.INFO: "#36a64f",      # Green
        AlertLevel.WARNING: "#ff9800",    # Orange
        AlertLevel.CRITICAL: "#ff0000",   # Red
        AlertLevel.SUCCESS: "#2196f3"     # Blue
    }
    
    # Emoji mapping
    EMOJIS = {
        AlertLevel.INFO: "ℹ️",
        AlertLevel.WARNING: "⚠️",
        AlertLevel.CRITICAL: "🚨",
        AlertLevel.SUCCESS: "✅"
    }
    
    def __init__(self):
        self.config = get_config()
        self.webhook_url = self.config.slack.webhook_url
        self.channel = self.config.slack.channel
        self.enabled = self.config.slack.enabled
        self.client = httpx.Client(timeout=10)
        
        if not self.enabled:
            logger.warning("Slack notifications disabled")
    
    def __del__(self):
        if hasattr(self, 'client'):
            self.client.close()
    
    def _send(self, payload: Dict[str, Any]) -> bool:
        """Send message to Slack webhook."""
        if not self.enabled:
            logger.info(f"[DRY RUN] Would send Slack message: {payload.get('text', '')[:100]}")
            return True
        
        try:
            response = self.client.post(self.webhook_url, json=payload)
            
            if response.status_code == 200:
                logger.debug("Slack message sent successfully")
                return True
            else:
                logger.error(f"Slack API error: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Failed to send Slack message: {e}")
            return False
    
    def send_anomaly_alert(self, anomaly: AnomalyResult) -> bool:
        """Send anomaly detection alert."""
        level = {
            AnomalySeverity.CRITICAL: AlertLevel.CRITICAL,
            AnomalySeverity.WARNING: AlertLevel.WARNING,
            AnomalySeverity.NORMAL: AlertLevel.INFO
        }.get(anomaly.severity, AlertLevel.INFO)
        
        emoji = self.EMOJIS[level]
        color = self.COLORS[level]
        
        # Build blocks
        blocks = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"{emoji} Anomaly Detected - {anomaly.severity.value.upper()}",
                    "emoji": True
                }
            },
            {
                "type": "section",
                "fields": [
                    {
                        "type": "mrkdwn",
                        "text": f"*Anomaly Score:*\n{anomaly.anomaly_score:.2%}"
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Confidence:*\n{anomaly.confidence:.2%}"
                    }
                ]
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*Contributing Factors:*\n• " + "\n• ".join(anomaly.contributing_factors) if anomaly.contributing_factors else "*Contributing Factors:*\nNone identified"
                }
            }
        ]
        
        # Add recommendations if present
        if anomaly.recommendations:
            blocks.append({
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*Recommendations:*\n" + "\n".join(f"• {r}" for r in anomaly.recommendations)
                }
            })
        
        # Add timestamp
        blocks.append({
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": f"Detected at {anomaly.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}"
                }
            ]
        })
        
        payload = {
            "channel": self.channel,
            "username": self.config.slack.username,
            "icon_emoji": self.config.slack.icon_emoji,
            "text": f"{emoji} Anomaly detected: {anomaly.severity.value}",
            "blocks": blocks,
            "attachments": [
                {
                    "color": color,
                    "fields": [
                        {
                            "title": metric,
                            "value": f"{score:.2%}",
                            "short": True
                        }
                        for metric, score in anomaly.raw_scores.items()
                    ]
                }
            ]
        }
        
        return self._send(payload)
    
    def send_prediction_alert(self, prediction: FailurePrediction) -> bool:
        """Send failure prediction alert."""
        level = AlertLevel.WARNING if prediction.probability < 0.8 else AlertLevel.CRITICAL
        emoji = self.EMOJIS[level]
        color = self.COLORS[level]
        
        ttf_text = (
            f"{prediction.estimated_time_to_failure.total_seconds() / 60:.0f} minutes"
            if prediction.estimated_time_to_failure
            else "Unknown"
        )
        
        blocks = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"{emoji} Failure Predicted: {prediction.failure_type.value.replace('_', ' ').title()}",
                    "emoji": True
                }
            },
            {
                "type": "section",
                "fields": [
                    {
                        "type": "mrkdwn",
                        "text": f"*Probability:*\n{prediction.probability:.0%}"
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Time to Failure:*\n{ttf_text}"
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Confidence:*\n{prediction.confidence:.0%}"
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Affected:*\n{', '.join(prediction.affected_components[:3])}"
                    }
                ]
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*Recommended Action:*\n{prediction.recommended_action}"
                }
            }
        ]
        
        # Add supporting evidence
        if prediction.supporting_evidence:
            blocks.append({
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*Evidence:*\n" + "\n".join(f"• {e}" for e in prediction.supporting_evidence[:5])
                }
            })
        
        payload = {
            "channel": self.channel,
            "username": self.config.slack.username,
            "icon_emoji": self.config.slack.icon_emoji,
            "text": f"{emoji} Failure predicted: {prediction.failure_type.value} ({prediction.probability:.0%})",
            "blocks": blocks,
            "attachments": [{"color": color}]
        }
        
        return self._send(payload)
    
    def send_remediation_result(self, result: ActionResult) -> bool:
        """Send remediation action result."""
        level = {
            ActionStatus.SUCCESS: AlertLevel.SUCCESS,
            ActionStatus.FAILED: AlertLevel.CRITICAL,
            ActionStatus.BLOCKED: AlertLevel.WARNING,
            ActionStatus.SKIPPED: AlertLevel.INFO
        }.get(result.status, AlertLevel.INFO)
        
        emoji = self.EMOJIS[level]
        color = self.COLORS[level]
        
        status_text = {
            ActionStatus.SUCCESS: "✅ Action Completed Successfully",
            ActionStatus.FAILED: "❌ Action Failed",
            ActionStatus.BLOCKED: "🚫 Action Blocked",
            ActionStatus.SKIPPED: "⏭️ Action Skipped"
        }.get(result.status, "Action Result")
        
        blocks = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": status_text,
                    "emoji": True
                }
            },
            {
                "type": "section",
                "fields": [
                    {
                        "type": "mrkdwn",
                        "text": f"*Action:*\n{result.action.action_type.value.replace('_', ' ').title()}"
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Target:*\n{result.action.target_namespace}/{result.action.target_name}"
                    }
                ]
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*Reason:*\n{result.action.reason}"
                }
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*Result:*\n{result.message}"
                }
            }
        ]
        
        # Add duration if available
        if result.duration_seconds:
            blocks.append({
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": f"Duration: {result.duration_seconds:.1f}s | Completed at {result.completed_at.strftime('%H:%M:%S UTC')}"
                    }
                ]
            })
        
        payload = {
            "channel": self.channel,
            "username": self.config.slack.username,
            "icon_emoji": self.config.slack.icon_emoji,
            "text": f"{emoji} Remediation: {result.action.action_type.value} -> {result.status.value}",
            "blocks": blocks,
            "attachments": [{"color": color}]
        }
        
        return self._send(payload)
    
    def send_daily_summary(
        self,
        anomalies_count: int,
        predictions_count: int,
        actions_count: int,
        success_rate: float,
        top_issues: List[str]
    ) -> bool:
        """Send daily summary report."""
        blocks = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": "📊 SelfHealStack Daily Summary",
                    "emoji": True
                }
            },
            {
                "type": "section",
                "fields": [
                    {"type": "mrkdwn", "text": f"*Anomalies Detected:*\n{anomalies_count}"},
                    {"type": "mrkdwn", "text": f"*Failures Predicted:*\n{predictions_count}"},
                    {"type": "mrkdwn", "text": f"*Actions Taken:*\n{actions_count}"},
                    {"type": "mrkdwn", "text": f"*Success Rate:*\n{success_rate:.0%}"}
                ]
            }
        ]
        
        if top_issues:
            blocks.append({
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "*Top Issues:*\n" + "\n".join(f"• {issue}" for issue in top_issues[:5])
                }
            })
        
        blocks.append({
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": f"Report generated at {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}"
                }
            ]
        })
        
        payload = {
            "channel": self.channel,
            "username": self.config.slack.username,
            "icon_emoji": self.config.slack.icon_emoji,
            "text": f"📊 Daily Summary: {actions_count} actions, {success_rate:.0%} success rate",
            "blocks": blocks
        }
        
        return self._send(payload)
    
    def send_test_message(self) -> bool:
        """Send a test message to verify connectivity."""
        payload = {
            "channel": self.channel,
            "username": self.config.slack.username,
            "icon_emoji": self.config.slack.icon_emoji,
            "text": "🧪 SelfHealStack test message - notifications are working!",
            "blocks": [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": "✅ SelfHealStack notifications are configured correctly!"
                    }
                }
            ]
        }
        
        return self._send(payload)


# Singleton instance
_notifier: Optional[SlackNotifier] = None


def get_notifier() -> SlackNotifier:
    """Get the global SlackNotifier instance."""
    global _notifier
    if _notifier is None:
        _notifier = SlackNotifier()
    return _notifier
